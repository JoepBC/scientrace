// /*
//  * Scientrace by Joep Bos-Coenraad
//  * primarily designed for researching concentrator systems
//  * at the Applied Material Science (AMS) department
//  * at the Radboud University Nijmegen, @see http://www.ru.nl/ams .
//  */
using System;

//TODO: implement random sphere point from 6502 @ http://stackoverflow.com/questions/5531827/random-point-on-a-given-sphere 

namespace Scientrace {
public class RandomToSurfaceLightSource {
		public RandomToSurfaceLightSource() {
		}
	}
}

