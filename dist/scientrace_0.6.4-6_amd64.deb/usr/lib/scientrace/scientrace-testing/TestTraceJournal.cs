// /*
//  * Scientrace by Joep Bos-Coenraad
//  * primarily designed for researching concentrator systems
//  * at the Applied Material Science (AMS) department
//  * at the Radboud University Nijmegen, @see http://www.ru.nl/ams .
//  */

using System;
using NUnit.Framework;

namespace ScientraceTesting {


[TestFixture()]
public class TestTraceJournal {

/*
	[Test()]
	public void TestSingleton() {
		Scientrace.TraceJournal tj = Scientrace.TraceJournal.Instance;
		Scientrace.Spot s1 = new Scientrace.Spot(new Scientrace.Location(0,0,0), DummySources.dEnv(), 1, 1, DummySources.dTrace());
		Scientrace.Spot s2 = new Scientrace.Spot(new Scientrace.Location(0,0,0), DummySources.dEnv(), 1, 1, DummySources.dTrace());
		tj.spots.Add(s1);
		tj.spots.Add(s2);
		Assert.AreEqual(2, tj.spots.Count );
		Scientrace.TraceJournal tj2 = Scientrace.TraceJournal.Instance;
		Assert.AreEqual(2, tj2.spots.Count);
	} */
}
}
