// /*
//  * Scientrace by Joep Bos-Coenraad
//  * primarily designed for researching concentrator systems
//  * at the Applied Material Science (AMS) department
//  * at the Radboud University Nijmegen, @see http://www.ru.nl/ams .
//  */
using System;
using NUnit.Framework;
namespace ScientraceTesting {
[TestFixture()]
public class MiscTests {
		
	[Test()]
	public void TestSharePrimes() {
			/*
		int a = 10;
		int b = 2;
		Assert.IsTrue(Scientrace.SpiralLightSource.sharePrimes(a,b));
		a = 10;
		b = 3;
		Assert.IsFalse(Scientrace.SpiralLightSource.sharePrimes(a,b));
		a = 95;
		b = 10;
		Assert.IsTrue(Scientrace.SpiralLightSource.sharePrimes(a,b));
		a = 95;
		b = 10;
		Assert.IsTrue(Scientrace.SpiralLightSource.sharePrimes(a,b));
		a = 98;
		b = 133;
		Assert.IsTrue(Scientrace.SpiralLightSource.sharePrimes(a,b));
		a = 97;
		b = 133;
		Assert.IsFalse(Scientrace.SpiralLightSource.sharePrimes(a,b));*/
	}
}
}

