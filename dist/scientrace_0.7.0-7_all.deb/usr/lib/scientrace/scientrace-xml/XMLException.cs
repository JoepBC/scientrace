using System;
namespace ScientraceXMLParser {

	public class XMLException : Exception {

		public XMLException (string message) : base(message) {
		}
	}
}