tar -cvvzf scientrace_0.6.4.orig.tar.gz --exclude="debian" scientrace-0.6.4/
